Validate the Installation
=========================

.. tabs::

  .. tab:: Cilium CLI

    .. include:: cli-download.rst
    .. include:: cli-status.rst
    .. include:: cli-connectivity-test.rst

  .. tab:: Manually

    .. include:: kubectl-status.rst
    .. include:: kubectl-connectivity-test.rst
