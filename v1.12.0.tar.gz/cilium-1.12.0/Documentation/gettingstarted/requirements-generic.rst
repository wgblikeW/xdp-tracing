**Requirements:**

* Kubernetes must be configured to use CNI (see `Network Plugin Requirements <https://kubernetes.io/docs/concepts/extend-kubernetes/compute-storage-net/network-plugins/#network-plugin-requirements>`_)
* Linux kernel >= 4.9.17

.. tip::

   See :ref:`admin_system_reqs` for more details on the system requirements.
